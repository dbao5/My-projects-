{\rtf1\ansi\ansicpg1252\cocoartf1671\cocoasubrtf400
{\fonttbl\f0\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c100000\c100000\c100000;\cssrgb\c0\c0\c0;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\sl360\partightenfactor0

\f0\fs32 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 README\
\
Course: cs400\
Semester: Spring 2019\
Project name: MyFirstJavaFx\
Team Members:\
DI BAO, lecture 001, and dbao5@wisc.edu\
\
Notes or comments to the grader:\
\
[I have followed all the instructions to finish this program. Also, I have checked this code a lot of times and everything seems to be ok.In addition, the comments also been added \
\
\
]}